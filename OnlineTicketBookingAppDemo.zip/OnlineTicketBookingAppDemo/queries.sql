select * from showdetails ; 
drop table showdetails ;